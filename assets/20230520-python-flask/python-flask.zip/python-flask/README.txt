Kapcsolódó YouTube videó:

	https://www.youtube.com/watch?v=0tXw9rHVklE
