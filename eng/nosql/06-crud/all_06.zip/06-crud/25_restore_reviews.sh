mongorestore --drop -d video -c reviews dump/reviews.bson
