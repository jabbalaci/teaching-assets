#!/usr/bin/env bash

cd /opt/studio3t
./Studio-3T &>/dev/null &
