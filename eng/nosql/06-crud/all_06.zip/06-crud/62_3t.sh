#!/usr/bin/env bash

DIR="/opt/studio3t"

cd $DIR
./Studio-3T &>/dev/null &
