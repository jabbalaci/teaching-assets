public class Main
{
    public static void main(String[] args)
    {
        String s = "Java is cool!";

        String vissza = StringUtils.strrev(s);

        System.out.println(s);
        System.out.println(vissza);

        System.out.println(StringUtils.isPalindrome("abbad"));
    }
}
