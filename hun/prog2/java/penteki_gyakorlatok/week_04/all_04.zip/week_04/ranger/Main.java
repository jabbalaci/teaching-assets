import java.util.List;

public class Main
{
    public static void main(String[] args)
    {
        List<Integer> numbers = PyUtils.range(20);
        System.out.println(numbers);
    }
}
