public class Main
{
    public static void main(String[] args)
    {
        double d = 2.0;
        int n = (int)d;

        // float f = (float)3.14;
        float f = 3.14f;

        double dd = f;
    }
}
