public class Main
{
    public static void main(String[] args)
    {
        // Scanner scanner = new Scanner(System.in);

        // String s = new String("valami");
        // String s = "valami";

        // Integer i = new Integer(5);
        Integer i = 5;

        // System.out.println(i);

        System.out.println(Integer.BYTES);
        System.out.println(Integer.MAX_VALUE);
    }
}
