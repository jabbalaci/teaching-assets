public class Main
{
    public static void main(String[] args)
    {
        // Math myMath = new Math();
        System.out.println(MyUtils.max(7, 3));

        System.out.println(MyUtils.duplaz(5));

        String s = "Java 11";
        System.out.println("Az s hossza: " + MyUtils.strlen(s));

        // MyUtils utils = new MyUtils();

        final int age = 20;
        // ++age;

        System.out.println(MyUtils.PI);
    }
}
