package com.example;

public class RadioButton extends UIWidget
{
//    public RadioButton() {
//        super(true);
//    }

    @Override
    public void render()
    {
        System.out.println("render RadioButton");
    }

    @Override
    public void enable() {
        // üres
    }
}
