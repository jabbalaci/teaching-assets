public class Main
{
    public static void main(String[] args)
    {
        String s = "aB42dEnEs";
        String result = StringUtils.swapCase(s);

        System.out.println(s);
        System.out.println(result);
    }
}
