public class Cat implements Animal
{

    @Override
    public void speak() {
        System.out.println("miaú");
    }

    @Override
    public void eat() {
        System.out.println("macska eszik");
    }
}
