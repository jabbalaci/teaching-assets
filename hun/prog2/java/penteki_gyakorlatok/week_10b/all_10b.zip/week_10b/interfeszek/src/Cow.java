public class Cow implements Animal
{
    @Override
    public void speak() {
        System.out.println("múúú");
    }

    @Override
    public void eat() {
        System.out.println("tehén eszik");
    }
}
