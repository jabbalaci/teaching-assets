public class Main
{
    public static void main(String[] args)
    {
        Monster kacsa = new Monster("kacsa");

        kacsa.attack();
        kacsa.fly();
        kacsa.swim();
    }
}
