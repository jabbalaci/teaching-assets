public interface CanSwim
{
    void swim();
}
