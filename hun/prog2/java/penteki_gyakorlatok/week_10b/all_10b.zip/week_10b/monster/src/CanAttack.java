public interface CanAttack
{
    void attack();
}
