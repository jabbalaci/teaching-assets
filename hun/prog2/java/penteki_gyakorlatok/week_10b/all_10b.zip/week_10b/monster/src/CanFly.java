public interface CanFly
{
    void fly();
}
