import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Main
{
    public static void main(String[] args)
    {
        List<Integer> szamok = new ArrayList<>();
        szamok.add(4);
        szamok.add(5);

        process(szamok);
    }

    private static void process(List<Integer> szamok)
    {
        // ...
    }
}
