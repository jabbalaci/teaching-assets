import utils.MyMath;
import utils.MyString;

public class Main
{
    public static void main(String[] args)
    {
        System.out.println(MyMath.duplaz(8));
        System.out.println(MyString.strlen("hello"));
    }
}
