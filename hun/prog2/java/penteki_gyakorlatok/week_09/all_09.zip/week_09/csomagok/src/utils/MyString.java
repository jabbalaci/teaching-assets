package utils;

public class MyString
{
    public static int strlen(String s) {
        return s.length();
    }
}
