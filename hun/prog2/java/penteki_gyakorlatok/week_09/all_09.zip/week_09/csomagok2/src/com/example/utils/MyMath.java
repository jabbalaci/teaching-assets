package com.example.utils;

public class MyMath
{
    public static int duplaz(int n) {
        return 2 * n;
    }
}
