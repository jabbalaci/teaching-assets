package com.example;

public class Valami
{

}
