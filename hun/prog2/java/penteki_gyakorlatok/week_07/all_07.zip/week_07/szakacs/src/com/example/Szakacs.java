package com.example;

public class Szakacs
{
    public void keszitLeves() {
        System.out.println("leves készítése");
    }

    public void keszitFoetel() {
        System.out.println("főétel készítése");
    }

    public void keszitSpecialitas() {
        System.out.println("vadas marha készítése");
    }
}
