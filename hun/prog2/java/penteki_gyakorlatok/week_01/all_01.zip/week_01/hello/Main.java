class Main
{
    public static void main(String[] args)
    {
        System.out.println("hello");
        System.out.println("world");
        System.out.print("aa");
        System.out.print("bb");
        System.out.println();

        int big = 100_000;

        long n = 2_147_483_648L;

        float pi = 3.14f;

        boolean ok = true;
        System.out.println(ok);

        // int z;
        // System.out.println(z);
    }
}
