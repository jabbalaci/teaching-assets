try:
    import pandas as pd
    print("# import pandas as pd")
except:
    pass
