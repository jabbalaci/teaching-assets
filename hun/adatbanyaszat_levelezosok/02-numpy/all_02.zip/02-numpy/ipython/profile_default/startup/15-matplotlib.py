try:
    import matplotlib.pyplot as plt
    print("# import matplotlib.pyplot as plt")
    import seaborn; seaborn.set()
    print("# import seaborn; seaborn.set()")
except:
    pass
