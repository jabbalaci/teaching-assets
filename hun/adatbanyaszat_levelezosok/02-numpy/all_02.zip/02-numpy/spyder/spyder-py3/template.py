#!/usr/bin/env python3
# coding: utf-8

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns; sns.set()    # set plot style
import pandas as pd


def main():
    print('Py3')

##############################################################################

if __name__ == "__main__":
    main()
