try:
    import line_profiler
    print("# import line_profiler")
except:
    pass

try:
    import memory_profiler
    print("# import memory_profiler")
except:
    pass
