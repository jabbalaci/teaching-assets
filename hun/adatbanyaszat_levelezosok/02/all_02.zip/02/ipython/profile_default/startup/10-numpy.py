try:
    import numpy as np
    print("# import numpy as np")
except:
    pass
