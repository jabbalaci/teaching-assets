mongorestore --drop -d movies -c movieDetails dump/movieDetails.bson
