#!/usr/bin/env bash

DIR="/opt/robo3t/bin"

cd $DIR
./robo3t &>/dev/null &
