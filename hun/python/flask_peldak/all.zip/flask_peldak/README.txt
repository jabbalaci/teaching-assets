Telepítés
=========

Linux
-----

    $ pip3 install flask --user -U

Windows
-------

    $ pip install flask
